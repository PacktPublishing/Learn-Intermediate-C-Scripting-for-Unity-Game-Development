﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test2 : MonoBehaviour
{

    public GameObject ball;
    public Transform spawnPoint;

    

    public float maxX;
    public float maxZ;
  
    // Start is called before the first frame update
    void Start()
    {
        //SpawnBall();
        
        InvokeRepeating("SpawnBall", 1f, 2f);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SpawnBall();
        }

        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos = Input.mousePosition;
            mousePos.z = 10f;

            Vector3 spawnPos = Camera.main.ScreenToWorldPoint(mousePos);

           // spawnPos.z = 5f;

            Instantiate(ball, spawnPos, Quaternion.identity);

        }
    }

    void SpawnBall()
    {
        float randomX = Random.Range(-maxX, maxX);
        float randomZ = Random.Range(-maxZ, maxZ);

        //Instantiate(ball, spawnPoint.position, Quaternion.identity);
        Vector3 randomPos = new Vector3(randomX, 5f , randomZ);
        Instantiate(ball,randomPos, Quaternion.identity);
    }
}
